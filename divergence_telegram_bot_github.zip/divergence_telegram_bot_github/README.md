# Telegram RSI Bullish Divergence Bot

Бот сканирует USDT perpetual/futures пары Bybit и BingX и отправляет в Telegram:

🟡 РАННЮЮ bullish divergence:
- цена сделала Lower Low;
- RSI(14) сделал Higher Low;
- RSI в районе дивергенции был ниже 30.

🟢 ПОДТВЕРЖДЁННУЮ:
- те же условия;
- текущий RSI уже выше 30.

## Важно

Версия рассчитана на **USDT perpetual/futures**, а не spot.

Bybit использует V5 `/v5/market/kline` для свечей и `/v5/market/tickers` для 24h тикеров.
BingX использует swap `/openApi/swap/v3/quote/klines` и `/openApi/swap/v2/quote/ticker`.

## Запуск

1. Создай Telegram-бота через @BotFather.
2. Скопируй token.
3. Узнай свой chat_id.
4. Скопируй `.env.example` в `.env`.
5. Заполни:
   TELEGRAM_BOT_TOKEN
   TELEGRAM_CHAT_ID
6. Установи зависимости:
   pip install -r requirements.txt
7. Запусти:
   python bot.py

API keys бирж для чтения рыночных данных в этой версии не нужны для Bybit. Для BingX публичный endpoint может зависеть от текущей политики API; если конкретный аккаунт/API требует авторизацию, добавление ключей можно включить отдельно.

## Логика

RSI рассчитывается как Wilder RSI(14).

Pivot Low:
- 3 свечи слева;
- 3 свечи справа.

Дивергенция:
- второй pivot low цены ниже первого минимум на 0.5% или больше;
- RSI второго pivot минимум на 2 пункта выше RSI первого;
- RSI в зоне дивергенции опускался ниже 30.

Настройки находятся в `.env`.

## Защита от повторов

Бот сохраняет уже отправленные сигналы в `sent_signals.json`, используя:
биржа + символ + таймфрейм + timestamp последнего pivot.

Это не торговый бот: он только анализирует рынок и отправляет уведомления.
